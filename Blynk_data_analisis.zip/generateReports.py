#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jul 26 10:52:28 2020

@author: david
"""

import pandas as pd
import os
import re



def createDir(weekNum):
    
    """Funcion que crea los directorios donde seran guardados los reportes generales"""
 
    # define the name of the directory to be created
    path = "./Resultados_" + weekNum
    
    try:
        os.mkdir(path)
    except OSError:
        print ("Creation of the directory %s failed" % path)
    else:
        print ("Successfully created the directory %s " % path)

    return path








filesNames = ["/camb_v7.csv", "/humedad_v8.csv", "/heatIndx_v9.csv", "/dewpoint_v10.csv"]

#re para encontrar las carpetas con los datos de las semanas
weeks = re.compile(r"semana\d*")

#revisa todo el directorio
files = os.listdir()

#crea un string a partir de los archivos encontrados 
#para que se le aplique el 'findall' con re.
directory = " ".join(files)

#encuentra las carpetas que corresponden a semanas
weekDir = weeks.findall(directory)



for w in weekDir:
    
    #lee los csv y crea un dataframe a partir de ellos
    #"semana\d"+"/nombreArchivo" -> direccion que se construye
    dfTemp = pd.read_csv(w+filesNames[0])
    dfHum = pd.read_csv(w+filesNames[1])
    dfHeat = pd.read_csv(w+filesNames[2])
    dfDewp = pd.read_csv(w+filesNames[3])
    
    
    #guarda los nombres de las columnas que contienen los datos 
    #de interés a ser extraidos
    col = [dfTemp.columns[0], dfHum.columns[0], dfHeat.columns[0], dfDewp.columns[0], dfDewp.columns[1]]
    #nombres de los encavezados de las columnas del dataframe que será
    #creado
    headers = ["temp", "hum", "heat", "dewPoint", "tiempo"]
    
    #columnas de datos que constituiran el dataframe
    data = [ dfTemp[ col[0]], dfHum[ col[1]], dfHeat[ col[2]], dfDewp[ col[3]], dfDewp[ col[4]] ]
    
    #union de las columnas de datos en un solo dataframe con los encabezados
    #predeterminados
    dfResult = pd.concat(data, axis = 1, keys = headers)
    
    #creacion del directorio donde se almacena el csv recien creado
    path = createDir(w)
    
    #guardado del directorio creado
    dfResult.to_csv( path +"/general_"+ w + ".csv")
    
    