#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul 25 08:34:48 2020

@author: david
"""

import datetime as dt 
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import base
import mergeReports as mr


"""
Los datos que se analicen deben ser tomados de noche, 
o en otras palabras, los ultimos datos que se debieron haber tomado, a la hora
de crear un reporte deben ser de noche.
"""

#for converting unix-time to normal format dateTime i used the explaination here:
#https://www.w3resource.com/python-exercises/date-time-exercise/python-date-time-exercise-6.php

#https://matplotlib.org/3.2.2/api/dates_api.html#matplotlib.dates.datestr2num
#https://www.geeksforgeeks.org/create-a-pandas-dataframe-from-lists/
#https://www.kite.com/python/answers/how-to-plot-dates-on-the-x-axis-of-a-matplotlib-plot-in-python
#https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.date_range.html
#https://stackoverflow.com/questions/36846060/how-to-replace-an-entire-column-on-pandas-dataframe
#https://matplotlib.org/3.2.1/api/_as_gen/matplotlib.axes.Axes.set_xticklabels.html
#https://www.tutorialspoint.com/matplotlib/matplotlib_setting_ticks_and_tick_labels.htm
#https://e2eml.school/matplotlib_ticks.html
#https://matplotlib.org/3.1.1/api/_as_gen/matplotlib.pyplot.subplots_adjust.html
    
print("Recuerde que los reportes deben hacerse los ultimos datos que fueron tomados de noche. ")
mode1 = int(input("desea hacer un reporte de las variables en general[0] o uno en específico[1]?->  "))


if mode1 == 0:
    
    #lista que contiene los nombres de los directorios que contienen 
    #los datos almacenados por semanas
    weeks = mr.findWeeks()
    
    #genera los csv que son la fusion de los diversos csv de cada variable 
    #ambiental, este proceso para cada semana
    mr.genCsv() 
    
    for w in weeks:
        
        df = pd.read_csv("./Resultados_"+ w + "/general_" + w + ".csv")
        
    
        #eliminar una columna que se crea automaticamente, la cual
        #contiene los indices y resulta innecesaria
        df = df.drop(["Unnamed: 0"], axis=1)
        
        #var = df.columns #['temp', 'hum', 'heat', 'dewPoint', 'tiempo']
        
        info = {"temp": {"dia_max": 23, "dia_min": 20, "noche_max": 18, "noche_min": 15, "label": "°C"}, 
                "hum": {"max" : 80, "min" : 60, "label": "(%)"}, 
                "heat": {"dia_max": 23, "dia_min": 20, "noche_max": 18, "noche_min": 15, "label": "°C"}, 
                "dewPoint": {"dia_max": 23, "dia_min": 20, "noche_max": 18, "noche_min": 15, "label": "°C"}} 

        
        df = base.dropOutLiers(df) #borra filas de valores que tienen errores en medicion
       
        #convierte el tiempo a dataTime stamp y la añade al dataframe
        t = base.convertTime(df)
        df["tiempo"] = t
        
        
#        print(df.head())
        #separa el dataframe en datos del dia y datos de la noche, y retorna 2 DF 
        #correspondientes
        day, night = base.partition(df)
        
        #transforma las fechas en numeros trabajables para matplotlib
        #basados en estos numeros se hace el "plot"
        x_axisDay = mdates.datestr2num(day["tiempo"])
        
        #etiquetas para el tiempo en el eje x
        x_labelsDay = base.xlabels(day)
        
        #transforma las fechas en numeros trabajables para matplotlib
        #basados en estos numeros se hace el "plot"
        x_axisNight = mdates.datestr2num(night["tiempo"])
        
        #etiquetas para el tiempo en el eje x
        x_labelsNight = base.xlabels(night)
        

        fig, (ax1, ax2) = plt.subplots(nrows = 2, ncols = 1, figsize = (15,10))
        ax1.set_title(label="Temperatura Diurna")
        ax2.set_title(label="Temperatura Nocturna")
        
        ax1.plot(range(len(day["temp"])), day["temp"])
        ax1.set_xticks(range(len(day["temp"])))
        ax1.set_xticklabels(x_labelsNight, rotation = 45)
        ax1.set_xlabel("Tiempo",labelpad = 5)
        ax1.grid()
        
        ax2.plot(range(len(night["temp"])), night["temp"])
        ax2.set_xticks(range(len(night["temp"])))
        ax2.set_xticklabels(x_labelsNight, rotation = 45)
        ax2.set_xlabel("Tiempo", labelpad = 5)
        ax2.grid()
        
        ax1.axhline(y = info["temp"]["dia_max"], linestyle='dashed', color="red", alpha = 0.9, label = info["temp"]["label"])
        ax1.axhline(y = info["temp"]["dia_min"], linestyle='dashed', color="red", alpha = 0.4, label = info["temp"]["label"])
        
        ax2.axhline(y = info["temp"]["noche_max"], linestyle='dashed', color="red", alpha = 0.9, label = info["temp"]["label"])
        ax2.axhline(y = info["temp"]["noche_min"], linestyle='dashed', color="red", alpha = 0.4, label = info["temp"]["label"])
        
        plt.subplots_adjust(hspace = 0.7)
        plt.legend()
        plt.show()
        
        break


            