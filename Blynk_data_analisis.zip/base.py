#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul 25 13:19:45 2020

@author: david
"""

import datetime as dt 
import pandas as pd 
import numpy as np
#import matplotlib.pyplot as plt
#import matplotlib.dates as mdates


#https://www.datacamp.com/community/tutorials/joining-dataframes-pandas
#https://www.geeksforgeeks.org/python-pandas-dataframe-drop_duplicates/

def convertTime(data, yr = True):
    """
    Funcion que recibe un data "DataFrame", y un booleano: yr, para 
    indicar si desea que se retorne, la lista de datetimes con el año
    o sin este. Por defecto yr = True
    """
    nRows = data.shape[0]
    
    complete = '%Y-%m-%d %H:%M:%S'
    incomplete = '%m-%d %H:%M:%S'
    time = []
    
    if (yr == 1):

        for i in range(nRows):
                time.append(dt.datetime.fromtimestamp(
                data["tiempo"][i]/1000      #se divide en 1000 porque 
                ).strftime(complete))       #los datos de blynk tienen 3 ceros extra
            
    else:
        
        for i in range(nRows):
                time.append(dt.datetime.fromtimestamp(
                data["tiempo"][i]/1000      #se divide en 1000 porque 
                ).strftime(incomplete))     #los datos de blynk tienen 3 ceros extra
         
            
    return time



def dropOutLiers(dataf):
    
    """Funcion que toma un dataframe y elimina los valores fuera de lo común
    que indican error en las mediciones
    """
    

    error1 = dataf.index[dataf["temp"] > 50].tolist()
    error2 = dataf.index[dataf["temp"] <= 0].tolist()
    error3 = dataf.index[dataf["hum"] < 20].tolist()
    error4 = dataf.index[dataf["hum"] > 90].tolist()
    
    err = error1 + error2 + error3 + error4
    print("Indices Ouliers: ", err)

    dataf = dataf.drop(err, axis=0)
    dataf.dropna
    dataf.drop_duplicates(subset ="tiempo", 
                     keep = False, inplace = True) 

    
    dataf = dataf.reset_index(drop=True)

    
    return dataf


def xlabels(dataf):
    """Funcion que da las etiquetas"""
    
    #funcion que da las etiquetas en el eje x
    #retorna una lista con un patron de 
    #4 espacios vacios y 1 fecha u hora
    
#    print(dataf["tiempo"])
    
    row = len(dataf.index) #cantidad de filas del dataframe para usar como 
    #base del loop

    time = []
    
    for i in range(row): 
        
        if(i % 60 != 0):
            time.append("")
        else:
            #accede a la columna de tiempo
            #toma el item multiplo de 5, ignora el año "[5:]"y pega la fecha
            time.append(dataf["tiempo"][i][5:])
                  
            
    return time


def dayNight(dataf):
    """Funcion que determina a partir del DataFrame que le ha sido pasado, 
    en qué índice del DataFrame comienza el día y la noche. 
    Retorna la lista de día y la de noche, con los índices en que empieza el día
    o la noche.
    """   
    
    row = len(dataf.index)
    day = []
    night = []
     
    allowDay = True
    allowNight = True
    
    for i in range( int(row/2) ):
        
        i = i*2
        
        
        if ( ( ( int(dataf["tiempo"][i][11:13]) < 18) and (int(dataf["tiempo"][i][11:13]) >= 6) ) and (allowDay) ):
                            
                day.append(i)
                allowDay = False
                allowNight = True
                       

        if ( ( (int(dataf["tiempo"][i][11:13]) < 6) or (int(dataf["tiempo"][i][11:13]) >=18)  ) and (allowNight) ):
            
                night.append(i)
                
                allowNight = False
                allowDay = True


    if(row != night[-1]):
        night.append(row)
        
    print("\nDia", day,"\nNoche", night)
             
    return day, night




def partition(dataf):
    
    #obtiene la lista de indices de cuando empieza la noche y el día
    #en el dataframe
    day, night = dayNight(dataf)
    
    #crea dataframes vacios para los datos del dia y la noche
    #los cuales serán rellenados a continuación
    dayDf = pd.DataFrame()
    nightDf = pd.DataFrame()
    
    
    #pega todas las filas de datos relevantes para el periodo del dia
    for i in range(len(day)):
        dayDf = dayDf.append( dataf[ day[i] : night[i]] )
        
    #pega todas las filas de datos relevantes para el periodo de la noche
    if (len(day) < len(night)):
        
        for i in range( len(day) - 1):
            nightDf = nightDf.append( dataf[ night[i] : day[i + 1] ])
            
        nightDf = nightDf.append( dataf[ night[i] :  ])
        
    
    #resetea los índices del dataframe sin guardar los indices viejos
    #para asi evitarse errores de acceso por indices
    dayDf = dayDf.reset_index(drop=True)
    nightDf =  nightDf.reset_index(drop =True)
            
    #retorna la particion de dataframes
    return dayDf, nightDf
    
    
    
    

